package advancedquestions;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author jon
 */
public class AdvancedQuestions {

    public static void main(String[] args) throws IOException {
        int sCase;
        System.out.println("Enter 1 for Sorting and Recursion, 2 for Enum and file input output, 3 for Enum and searching.");
        Scanner input = new Scanner(System.in);
        while (true) {
            sCase = input.nextInt();
            switch (sCase) {
                case 1:
                    RecursionSort.run();
                    break;
                case 2:
                    EnumIO.run();
                    break;
                case 3:
                    SearchIO.run();
                    break;
                default:
                    System.out.println("This is not a valid choice");
            }

        }
    }
}
