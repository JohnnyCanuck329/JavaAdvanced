package advancedquestions;

import java.io.IOException;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author jon
 */
public class SearchIO {

    //Gateway----------------------------------------------------------------------------------------------
    public static void run() throws IOException {

        File file = new File("files/file.txt");
        if (!file.exists()) {
            file.createNewFile();
        }

        ArrayList<String> names;
        try (Scanner s = new Scanner(file)) {
            names = new ArrayList<>();
            while (s.hasNext()) {
                names.add(s.next());
            }
        }

        Scanner input = new Scanner(System.in);
        loop:
        while (true) {
            System.out.println("This is a guest list. To invite a new guest enter \"new\", to search the guest list enter \"search\" and to exit enter anything else.");
            switch (input.nextLine()) {
                case ("search"):
                    System.out.println("Please enter the name you are looking for");
                    String name = input.nextLine();
                    if (Search(names, name)) {
                        System.out.println("Invited, come on in!");

                    } else {
                        System.out.println("Not invited, do not allow in.");
                    }
                    break;
                case ("new"):
                    System.out.println("Please enter the name of the guest you'd like to add.");
                    name = input.nextLine();
                    if (!Search(names, name)) {
                        names.add(name);
                        Create(names);
                        System.out.println("Guest list updated.");

                    } else {
                        System.out.println("This person is already invited.");
                    }
                    break;
                default:
                    break loop;
            }

        }

    }
    
    //----------------------------------------------------------------------------------------------

    private static boolean Search(ArrayList<String> list, String keyword) {
        for (String incr : list) {
            if (incr.equals(keyword)) {
                return true;
            }
        }
        return false;
    }

    private static void Create(ArrayList<String> list) throws IOException {
        Path file = Paths.get("files/file.txt");
        Files.write(file, list, StandardCharsets.UTF_8);

    }

}
