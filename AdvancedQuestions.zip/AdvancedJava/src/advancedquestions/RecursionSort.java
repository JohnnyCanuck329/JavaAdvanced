package advancedquestions;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author jon
 */
public class RecursionSort {

   //Gateway----------------------------------------------------------------------------------------------
    public static void run() {
        ArrayList<Integer> markArray = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        System.out.println("This program will store and sort you marks.");
        while (true) {
            System.out.println("Enter your marks. When you're finished, type \"show list\" to show your marks. This is case sensitive, so make sure it's all lower case.");
            String num = input.nextLine();
            try {
                int mark = Integer.parseInt(num);
                if (mark < 101 && mark > -1) {
                    markArray.add(mark);
                } else {
                    System.out.println("This is not a valid mark");
                }

            } catch (NumberFormatException e) {
                if (num.equals("show list")) {
                    break;

                } else {
                    System.out.println("This program doesn't recognise letters as marks, please input a whole number.");
                }
            }
        }
        System.out.println("Your marks from lowest to highest are:");
        sort(markArray, 0, markArray.size() - 1).forEach((i) -> {
            System.out.println(i);
        });
    }
//----------------------------------------------------------------------------------------------
    
    public static int DividePoint(ArrayList<Integer> list, int min, int max) {
        int center = list.get(max);
        int increment = (min - 1);
        for (int j = min; j < max; j++) {
            if (list.get(j) < center) {
                increment++;
                Collections.swap(list, increment, j);
            }
        }
        Collections.swap(list, increment + 1, max);

        return increment + 1;
    }
//----------------------------------------------------------------------------------------------    

    public static ArrayList<Integer> sort(ArrayList<Integer> list, int base, int abs) {

        if (base < abs) {

            int DP = DividePoint(list, base, abs);

            sort(list, base, DP - 1);
            sort(list, DP + 1, abs);
        }
        return list;
    }

}
