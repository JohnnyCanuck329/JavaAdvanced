package advancedquestions;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author jon
 */
public class EnumIO {

    public enum Chocolate {
        Skor, Wunderbar, Twix, Areo, Mars, Snickers
    }

    //Gateway----------------------------------------------------------------------------------------------
    public static void run() throws IOException {

        File f = new File("files/choco.txt");
        if (!f.exists()) {
            f.createNewFile();
        }

        ArrayList<Chocolate> lable;
        try (Scanner s = new Scanner(f)) {
            lable = new ArrayList<>();
            while (s.hasNext()) {
                lable.add((Chocolate.valueOf(s.next())));
            }
        }

        loop:
        while (true) {
            Scanner input = new Scanner(System.in);
            System.out.println("This program will keep track of all the chocolate you add to your cart. To add a chocolate bar enter \"add\", to see the chocolate bars in your cart enter \"view\" and enter anything else to exit.");
            System.out.println("It's equipped to handle the following chocolate bars: Skor, Wunderbar, Twix, Areo, Mars, Snickers");
            switch (input.nextLine()) {
                case "add":
                    System.out.println("Enter the name of the chocolate bar you added to your cart.");
                    try {
                        lable.add((Chocolate.valueOf(input.next())));
                        System.out.println("Chocolate bar added to cart.\n");
                        WriteToFile(lable, "files/choco.txt");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Not a possible entry. Remember this program is case sensitive.");
                    }
                    break;
                case "view":
                    System.out.println("These are the chocolate bars in your basket.");
                    lable.forEach((i) -> System.out.println(i.name()));
                    break;
                default:
                    break loop;
            }

        }
    }
    
    //----------------------------------------------------------------------------------------------

    private static void WriteToFile(ArrayList<Chocolate> list, String path) throws IOException {
        ArrayList<String> newList = new ArrayList<>();
        list.forEach((i) -> newList.add(i.name()));
        Path file = Paths.get(path);
        Files.write(file, newList, StandardCharsets.UTF_8);

    }

}
